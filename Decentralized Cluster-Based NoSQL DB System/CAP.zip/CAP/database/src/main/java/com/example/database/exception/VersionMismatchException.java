package com.example.database.exception;

public class VersionMismatchException extends Exception {

    public VersionMismatchException(String message) {
        super(message);
    }
}
