package com.example.bootstrapnode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootstrapnodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
