package com.example.bootstrapnode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootstrapnodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootstrapnodeApplication.class, args);
	}

}
